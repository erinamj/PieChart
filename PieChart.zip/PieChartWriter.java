import java.awt.*;
import javax.swing.*;

@SuppressWarnings("serial")
public class PieChartWriter extends JPanel {
	private int width = 500;
	private int length = 300;
	private int x = 50;
	private int y = 50;
	private int diameter = 150;
	private int startAngle = 0;
	public double s; // Amount's Sum

	private Color Color0 = Color.white; // ngjyra e prapavise se dritares

	public String Label1; // deklarimi i variablave te kerkuara ne detyre
	public double Amount1;
	public Color Color1;
	public int n;

	public String Label2;
	public double Amount2;
	public Color Color2;
	public int d;

	public String Label3;
	public double Amount3;
	public Color Color3;
	public int t;

	public String Label4;
	public double Amount4;
	public Color Color4;
	public int r;

	public String Label5;
	public double Amount5;
	public Color Color5;
	public int p;

	public String Label6;
	public double Amount6;
	public Color Color6;
	public int j;

	JFrame k = new JFrame();

	/**
	 * Konstruktori PieChartWriter i aplikacionit
	 * 
	 * @param label  - emri qe paraqitet
	 * @param amount - masa/totali qe paraqitet
	 * @param c      - ngjyra qe paraqitet ne PieChart
	 */
	public PieChartWriter() { // shfaqja e kornizes
		k.getContentPane().add(this);
		k.setSize(width, length);
		k.setVisible(true);

	}

	public void setTitle(String title) {
		k.setTitle(title);
	}

	// Metodat
	public void setSlice1(String label, double amount, Color c) {
		this.Label1 = label;
		this.Amount1 = amount;
		this.Color1 = c;
	}

	public void setSlice2(String label, double amount, Color c) {
		this.Label2 = label;
		this.Amount2 = amount;
		this.Color2 = c;
	}

	public void setSlice3(String label, double amount, Color c) {
		this.Label3 = label;
		this.Amount3 = amount;
		this.Color3 = c;
	}

	public void setSlice4(String label, double amount, Color c) {
		this.Label4 = label;
		this.Amount4 = amount;
		this.Color4 = c;
	}

	public void setSlice5(String label, double amount, Color c) {
		this.Label5 = label;
		this.Amount5 = amount;
		this.Color5 = c;
	}

	public void setSlice6(String label, double amount, Color c) {
		this.Label6 = label;
		this.Amount6 = amount;
		this.Color6 = c;
	}

	// Dritarja e programit
	public void paintComponent(Graphics g) {
		s = (Amount1 + Amount2 + Amount3 + Amount4 + Amount5 + Amount6);

		g.setColor(Color0);
		g.fillRect(0, 0, width, length);

		g.setColor(Color1);
		n = (int) Math.round((Amount1 * 360) / s);
		g.fillArc(x, y, diameter, diameter, startAngle, n);
		g.drawString(Label1, length - 50, 80);

		g.setColor(Color2);
		d = (int) Math.round((Amount2 * 360) / s);
		g.fillArc(x, y, diameter, diameter, n, d);
		g.drawString(Label2, length - 50, 100);

		g.setColor(Color3);
		t = (int) Math.round((Amount3 * 360) / s);
		g.fillArc(x, y, diameter, diameter, n + d, t);
		g.drawString(Label3, length - 50, 120);

		g.setColor(Color4);
		r = (int) Math.round((Amount4 * 360) / s);
		g.fillArc(x, y, diameter, diameter, n + d + t, r);
		g.drawString(Label4, length - 50, 140);

		g.setColor(Color5);
		p = (int) Math.round((Amount5 * 360) / s);
		g.fillArc(x, y, diameter, diameter, n + d + t + r, p);
		g.drawString(Label5, length - 50, 160);

		g.setColor(Color6);
		j =(int) Math.round((Amount6 * 360) / s);
		g.fillArc(x, y, diameter, diameter,  n + d + t + r + p, j);
		g.drawString(Label6, length - 50, 180);

	}
}