import java.awt.*;

public class TestPieChart // klasa main
{
	public static void main(String[] args) {
		PieChartWriter po = new PieChartWriter();
		
		po.setTitle("How I spend my day");
		po.setSlice1("Sleep: 7 hours", 7, Color.black);
		po.setSlice4("Recreation: 9 hours", 9, Color.gray);
		po.setSlice2("In class: 3 hours", 3, Color.blue);
		po.setSlice3("Homework: 5 hours", 5, Color.red);
		po.setSlice5("", 0, Color.green);
		po.setSlice6("", 0, Color.yellow);
		
	}
}